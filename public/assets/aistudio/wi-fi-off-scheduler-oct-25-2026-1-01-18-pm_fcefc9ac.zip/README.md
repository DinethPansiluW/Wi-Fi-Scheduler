# Wi-Fi OFF Scheduler

A modern, production-grade Windows desktop application built with Electron to replace legacy batch scripts with an intuitive, flexible, and robust automated scheduling engine.

---

## Highlights & Features

- **Standard User Execution (`asInvoker`)**: Never requires Administrator privileges. Windows `netsh wlan disconnect` and `connect` work cleanly in standard user context.
- **Sanitized Execution**: All system commands (`netsh` and `ipconfig`) are dispatched using `child_process.execFile` with discrete argument vectors—never raw shell string concatenation. SSIDs with spaces, quotes, or special characters (e.g., `Hemis WiFi`, `John's "5G"`) run without risk of command injection or truncation.
- **Tolerant State Parsing**: Parses `netsh wlan show interfaces` specifically extracting `State` and `SSID` while strictly ignoring `BSSID`.
- **Advanced Flexible Rules Engine**:
  - **Actions**: Disconnect Wi-Fi, Connect to saved profile, Toggle (disconnect if connected, otherwise connect), and Renew IP (`ipconfig /renew`).
  - **Network Filters**: Target ANY network, ONLY specified SSIDs (with interactive chip tags), or ALL EXCEPT specified SSIDs.
  - **Cadences**: Once (specific date & time with past date protection), Daily, Weekly (multi-select days with quick presets: Weekdays, Weekends, Every day), and Monthly (handles shorter months e.g. Feb 28/29, Apr 30 clamping).
  - **Auto-Reconnect**: Optional automatic reconnection after *N* minutes for Disconnect rules.
  - **Sleep Wake-Up & Start Catch-Up**: Evaluates whether an occurrence was missed within the last *N* minutes (default 10m) while the PC was suspended or off, and runs once without duplicate firing.
- **Windows 11 Fluent & Glassmorphism Design**: Frosted glass cards, Segoe UI Variable font stack, electric blue to violet gradients, dark/light/system themes, custom frameless titlebar with live Wi-Fi state chip, and system tray minimization.
- **Atomic Data Persistence**: Atomic writes (`write to temp` & `renameSync`) prevent file corruption in `%APPDATA%/wifi-off-scheduler` for rules, settings, and up to 500 activity logs.

---

## File Structure

```text
wifi-off-scheduler/
├── .gitignore
├── build/
│   ├── icon.ico
│   └── README.txt
├── main.js
├── package.json
├── preload.js
├── README.md
├── renderer/
│   ├── app.js
│   ├── index.html
│   └── styles.css
├── scheduler.js
├── store.js
├── test-schedule.js
└── wifi.js
```

---

## How to Run & Build

### 1. Prerequisites
- Node.js (v18, v20, or v22 recommended)
- Windows 10 or Windows 11

### 2. Install Dependencies
```bash
npm install
```

### 3. Run Self-Tests (Next-Run Math Verification)
```bash
npm run test:schedule
```
Verifies 21 algorithmic test cases for single occurrence, daily rollover, weekly multi-day patterns, monthly 31-day clamping, and sleep catch-up logic without any external testing dependencies.

### 4. Run Development Desktop App
```bash
npm start
```
Launches the Electron application on your Windows machine with system tray integration and live hardware polling.

### 5. Build Standalone Windows Executables
```bash
npm run dist
```
Outputs ready-to-use binaries in the `dist/` folder:
- **NSIS Setup Installer**: `dist/Wi-Fi OFF Scheduler-Setup-1.0.0.exe` (User-configurable installation path, desktop and Start Menu shortcuts, clean uninstaller).
- **Portable Executable**: `dist/Wi-Fi OFF Scheduler-Portable-1.0.0.exe` (Zero-installation portable version, ideal for USB drives).

---

## Comparison: Old BAT Script vs. Wi-Fi OFF Scheduler

| Feature | Old Batch Script Tool | Wi-Fi OFF Scheduler |
| :--- | :--- | :--- |
| **Interface** | Blinking black CMD prompt window | Windows 11 Fluent Glassmorphic desktop app |
| **Rules Capacity** | Single hardcoded schedule | Unlimited customizable schedules with wizard |
| **SSID Filter** | Basic string check, breaks on quotes | Robust array filtering, supports spaces/quotes/symbols |
| **Timing Accuracy** | Polling sleep delays in seconds | 15s authoritative ticking engine with next-run math |
| **PC Sleep Handling** | Dies or skips silently on sleep | `powerMonitor` resume listener + 10m catch-up engine |
| **System Tray** | None (clutters taskbar or tray-less) | Full Windows tray icon with quick pause & start toggles |
| **Logging** | None or append to raw txt | Interactive table with search, CSV & JSON export |
| **Safety** | String concatenation vulnerability | `child_process.execFile` argument vectors (`asInvoker`) |

---

## License

MIT License. Built for seamless Windows network automation.
